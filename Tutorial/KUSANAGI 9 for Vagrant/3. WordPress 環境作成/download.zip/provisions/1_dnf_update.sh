#!/bin/bash

dnf update -y